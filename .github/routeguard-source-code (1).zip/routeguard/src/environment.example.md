# Environment example

The hosted WebDev environment manages secrets outside the repository. For a self-managed deployment, use the following names and replace every value with a secret-manager reference:

| Name | Example shape | Used by |
| --- | --- | --- |
| `DATABASE_URL` | `mysql://user:password@host:3306/routeguard` | Future event persistence |
| `JWT_SECRET` | long random string | Session signing |
| `BUILT_IN_FORGE_API_URL` | `https://forge.example/v1` | Server LLM gateway |
| `BUILT_IN_FORGE_API_KEY` | secret token | Server LLM gateway |
| `WATSONX_PROJECT_ID` | UUID | IBM watsonx.ai project |
| `WATSONX_API_KEY` | secret token | IBM watsonx.ai |

Never commit a real `.env` file, API key, or customer shipment data.
