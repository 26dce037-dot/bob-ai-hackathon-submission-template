# RouteGuard source map

RouteGuard is implemented as a WebDev full-stack project. The working source is split into `client/` (React UI) and `server/` (tRPC procedures) because the managed scaffold supplies typed client/server boundaries. The Bobathon-required `src/` directory is retained as this source-map entry point so evaluators can quickly find the implementation.

- `client/src/pages/Home.tsx` — control-tower dashboard, disruption queue, cold-chain view, fleet view, and Ask Bob side panel.
- `client/src/index.css` — visual system, typography, motion, and responsive dark-cockpit styling.
- `server/routers.ts` — `assistant.ask` procedure. It keeps model credentials server-side and sends a bounded operational context to the built-in LLM helper, with a deterministic demo fallback.
- `server/_core/llm.ts` — WebDev-provided LLM bridge. In an IBM-hosted deployment, the same prompt contract is the integration point for watsonx.ai / Granite.

No credentials or live customer data are stored in this repository. Seeded demo data makes the interface reproducible for judges.
