import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{ message: { content: "Prioritise SHP-1048, then deploy TRK-088 with operator approval." } }],
  }),
}));

function createContext(): TrpcContext {
  return {
    user: undefined,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("assistant.ask", () => {
  it("returns the assistant recommendation in demo context", async () => {
    const caller = appRouter.createCaller(createContext());
    const result = await caller.assistant.ask({
      query: "What needs action first?",
      context: '{"shipments":[{"id":"SHP-1048","value":"$612K"}]}',
    });

    expect(result.mode).toBe("llm");
    expect(result.answer).toContain("SHP-1048");
  });
});
