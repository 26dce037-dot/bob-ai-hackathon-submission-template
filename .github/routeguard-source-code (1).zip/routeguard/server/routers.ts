import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

const fallbackAnswer = "Prioritise SHP-1048. It combines the highest cargo exposure ($612K) with a 14-minute temperature excursion and a Rotterdam handoff delay. Recommend the Antwerp re-route, deploy TRK-088 from Utrecht, and require operator approval before execution.";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  assistant: router({
    ask: publicProcedure
      .input(z.object({ query: z.string().min(1).max(1200), context: z.string().max(12000).optional() }))
      .mutation(async ({ input }) => {
        try {
          const response = await invokeLLM({
            model: "gpt-5-mini",
            messages: [
              {
                role: "system",
                content: "You are Bob, the RouteGuard supply-chain operations assistant. Correlate shipment disruption, fleet availability, and cold-chain sensor context. Respond in 3 concise sentences: priority, rationale, and recommended operator-approved next step. Never claim to have executed an action.",
              },
              {
                role: "user",
                content: `Operator question: ${input.query}\n\nCurrent network context:\n${input.context ?? "Demo context unavailable; use conservative reasoning."}`,
              },
            ],
            reasoning: { effort: "low" },
          });
          const content = response.choices?.[0]?.message?.content;
          const answer = typeof content === "string" && content.trim() ? content.trim() : fallbackAnswer;
          return { answer, mode: "llm" as const };
        } catch (error) {
          console.warn("[RouteGuard] Assistant fallback activated", error);
          return { answer: fallbackAnswer, mode: "demo" as const };
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
