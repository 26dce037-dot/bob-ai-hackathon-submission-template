# Screenshot evidence

This folder contains the visual evidence for the running RouteGuard application. The recommended sequence is `01-control-tower.png`, `02-disruptions.png`, and `03-cold-chain.png`. Replace or supplement these captures with final screenshots from the public deployment before submission.
