# RouteGuard — Supply Chain Disruption Assistant

**RouteGuard** is a Bob-ready control tower for supply-chain operators managing disruption, fleet capacity, and temperature-sensitive cargo. It converts a noisy network of shipment events, carrier changes, idle assets, and cold-chain sensor readings into a single ranked set of operator-approved next moves.

## Team

Team RouteGuard is submitting to the **AI** track. Replace the placeholder lead and member contact details in `submission.yaml` before publishing the repository.

## Problem statement

Weather events, port strikes, and geopolitical crises cascade across active shipments in ways that are difficult to track manually. Fleet assets can sit idle while other routes are overloaded, and cold-chain breaches may not be discovered until delivery—after a high-value cargo has already been compromised.

## Solution

RouteGuard presents a live operations cockpit with a disruption priority queue, network pulse, fleet redeployment view, and cold-chain watch. The Ask Bob workflow correlates seeded operational context and returns a concise recommendation with rationale; in a production IBM deployment, the same server-side prompt contract maps to watsonx.ai / Granite and real telemetry connectors.

## Key features

- **Priority queue:** ranks shipments by cargo exposure and time-to-impact.
- **Disruption actions:** recommends a re-route or carrier alternative for each affected shipment.
- **Fleet utilisation:** surfaces idle trucks and containers and matches them to current risk.
- **Cold-chain watch:** classifies temperature excursions and highlights regulatory review risk.
- **Ask Bob:** server-side assistant with an operator-approval guardrail and deterministic demo fallback.

## Technology

The application uses React 19, TypeScript, Tailwind CSS, Vite, Express, tRPC, Vitest, Lucide icons, and the WebDev server-side LLM bridge. The integration boundary is designed for IBM Bob and watsonx.ai / Granite. The current demo is intentionally reproducible with seeded data and does not require external credentials.

## Run locally

```bash
cd /home/ubuntu/routeguard
pnpm install
pnpm dev
```

Open the preview URL printed by the WebDev server. For a production build, run `pnpm build` and then `pnpm start`.

## Demo

- **Live demo:** see `demo/live-demo-url.txt`.
- **Video:** see `demo/demo-video-link.txt`; it is marked as not recorded until the team captures the required 3–5 minute walkthrough.
- **Screenshots:** see `demo/screenshots/`.

## Known limitations

The current submission uses seeded operational data so judges can reproduce the story without private carrier or IoT credentials. The IBM Bob / watsonx mapping is implemented at the server-side assistant boundary, but production deployment still needs live connector credentials, a real model project, carrier API contracts, and an operator identity model. Re-routing is recommendation-only; RouteGuard never executes a carrier change without an approval step.

## What we are most proud of

The strongest work is the decision surface: every risk signal is paired with a proposed next move, a time window, and an accountable operator step. This makes the demo more than a dashboard—it shows how Bob can sit in the loop between detection and safe operational action.

## Repository map

| Path | Purpose |
| --- | --- |
| `submission.yaml` | Structured evaluator metadata |
| `client/` | React dashboard and visual system |
| `server/` | tRPC API and Ask Bob procedure |
| `src/` | Bobathon source map and environment documentation |
| `docs/` | Problem, solution, architecture, and setup documentation |
| `demo/` | Live URL, video status, and screenshots |
| `presentation/` | Hackathon slide deck |

