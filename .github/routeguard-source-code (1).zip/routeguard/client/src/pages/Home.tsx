import { useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  Bot,
  BrainCircuit,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  Clock3,
  Container,
  Cpu,
  Droplets,
  Filter,
  Gauge,
  LocateFixed,
  Menu,
  MessageSquareText,
  MoreHorizontal,
  PackageCheck,
  Radio,
  RefreshCw,
  Route as RouteIcon,
  Send,
  ShieldCheck,
  Snowflake,
  Sparkles,
  Truck,
  Waves,
  X,
  Zap,
} from "lucide-react";
import { trpc } from "@/lib/trpc";

type NavItem = { label: string; icon: React.ComponentType<{ size?: number; strokeWidth?: number }> };

const navItems: NavItem[] = [
  { label: "Control tower", icon: Activity },
  { label: "Disruptions", icon: AlertTriangle },
  { label: "Cold chain", icon: Snowflake },
  { label: "Fleet utilisation", icon: Truck },
];

const shipments = [
  { id: "SHP-1048", lane: "Rotterdam → Chicago", cargo: "mRNA vaccines", value: "$612K", risk: "Critical", eta: "18h 42m", action: "Re-route via Antwerp" },
  { id: "SHP-1043", lane: "Busan → Long Beach", cargo: "Semiconductor resin", value: "$284K", risk: "High", eta: "2d 04h", action: "Use carrier: Maersk" },
  { id: "SHP-1039", lane: "Mumbai → Dubai", cargo: "Fresh biologics", value: "$196K", risk: "Medium", eta: "1d 11h", action: "Monitor sensor feed" },
  { id: "SHP-1031", lane: "Singapore → Hamburg", cargo: "Specialty chemicals", value: "$421K", risk: "Watch", eta: "3d 08h", action: "No action required" },
];

const fleet = [
  { asset: "TRK-088", type: "Reefer truck", location: "Utrecht yard", utilisation: 18, status: "Idle", recommendation: "Deploy to SHP-1048" },
  { asset: "CNT-402", type: "40ft cold container", location: "Antwerp port", utilisation: 94, status: "Active", recommendation: "Protected lane" },
  { asset: "VSL-017", type: "Feeder vessel", location: "North Sea", utilisation: 61, status: "Active", recommendation: "On schedule" },
];

const sensorEvents = [
  { time: "09:42", shipment: "SHP-1048", reading: "9.8°C", duration: "14 min", severity: "Regulatory review", color: "red" },
  { time: "09:18", shipment: "SHP-1039", reading: "7.2°C", duration: "4 min", severity: "Watch", color: "amber" },
  { time: "08:55", shipment: "SHP-1039", reading: "2.9°C", duration: "—", severity: "Recovered", color: "green" },
];

const riskTone: Record<string, string> = {
  Critical: "text-[#ff7a69] bg-[#3a1d27] border-[#783644]",
  High: "text-[#ffba68] bg-[#3b2b1c] border-[#715126]",
  Medium: "text-[#eecb6b] bg-[#37301e] border-[#655a2b]",
  Watch: "text-[#8db7ff] bg-[#1d2c46] border-[#2f4b78]",
};

const chipTone: Record<string, string> = {
  red: "text-[#ff9585] bg-[#3a1d27]",
  amber: "text-[#f4c568] bg-[#3b2b1c]",
  green: "text-[#77d4a0] bg-[#173428]",
};

export default function Home() {
  const [activeNav, setActiveNav] = useState(() => {
    if (typeof window === "undefined") return "Control tower";
    if (window.location.pathname === "/disruptions") return "Disruptions";
    if (window.location.pathname === "/cold-chain") return "Cold chain";
    if (window.location.pathname === "/fleet") return "Fleet utilisation";
    return "Control tower";
  });
  const [selectedShipment, setSelectedShipment] = useState(shipments[0]);
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [messages, setMessages] = useState([
    { role: "assistant", text: "I’m monitoring 124 shipments, 38 fleet assets, and 612 cold-chain sensor points. Ask me what needs attention first." },
  ]);
  const askAssistant = trpc.assistant.ask.useMutation();

  const activeView = useMemo(() => {
    if (activeNav === "Disruptions") return "disruptions";
    if (activeNav === "Cold chain") return "cold";
    if (activeNav === "Fleet utilisation") return "fleet";
    return "overview";
  }, [activeNav]);

  const handleAsk = async () => {
    const trimmed = query.trim();
    if (!trimmed || askAssistant.isPending) return;
    setMessages((current) => [...current, { role: "user", text: trimmed }]);
    setQuery("");
    try {
      const response = await askAssistant.mutateAsync({ query: trimmed, context: JSON.stringify({ shipments, fleet, sensorEvents }) });
      setMessages((current) => [...current, { role: "assistant", text: response.answer }]);
    } catch {
      setMessages((current) => [...current, { role: "assistant", text: "Demo mode is active. Prioritise SHP-1048: it has a 14-minute excursion and the Rotterdam port strike has closed its current handoff. Recommend the Antwerp re-route and deploy TRK-088." }]);
    }
  };

  return (
    <div className="min-h-screen bg-[#0c1118] text-[#e7edf4]">
      <div className="flex min-h-screen">
        <aside className="hidden w-[248px] shrink-0 border-r border-white/[0.07] bg-[#0e151e] px-4 py-5 lg:flex lg:flex-col">
          <div className="mb-10 flex items-center gap-3 px-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f07c59] text-[#11161d] shadow-[0_8px_30px_rgba(240,124,89,0.2)]">
              <RouteIcon size={23} strokeWidth={2.4} />
            </div>
            <div>
              <div className="font-display text-lg font-semibold tracking-tight">RouteGuard</div>
              <div className="text-[10px] font-medium uppercase tracking-[0.19em] text-[#708094]">Bob operations cockpit</div>
            </div>
          </div>
          <div className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#566578]">Workspace</div>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = item.label === activeNav;
              return (
                <button key={item.label} onClick={() => setActiveNav(item.label)} className={`group flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm transition ${active ? "bg-[#172332] text-white shadow-inner shadow-white/[0.03]" : "text-[#8897aa] hover:bg-white/[0.04] hover:text-[#dce6ef]"}`}>
                  <Icon size={17} strokeWidth={active ? 2.2 : 1.8} />
                  <span>{item.label}</span>
                  {item.label === "Disruptions" && <span className="ml-auto rounded-full bg-[#f07c59] px-2 py-0.5 text-[10px] font-bold text-[#161a20]">7</span>}
                </button>
              );
            })}
          </nav>
          <div className="mt-8 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#566578]">Connected systems</div>
          <div className="mt-3 space-y-2 px-3">
            {[
              ["Instana telemetry", "Healthy", "#68ce9b"],
              ["Carrier APIs", "Synced 2m ago", "#68ce9b"],
              ["Cold-chain IoT", "2 warnings", "#f4b65f"],
            ].map(([label, status, color]) => <div key={label} className="flex items-center justify-between text-xs"><span className="text-[#8996a7]">{label}</span><span className="flex items-center gap-1.5 text-[10px] text-[#8190a0]"><span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: color }} />{status}</span></div>)}
          </div>
          <div className="mt-auto rounded-2xl border border-[#263445] bg-[#121d2a] p-4">
            <div className="mb-2 flex items-center gap-2 text-[#f2c16e]"><ShieldCheck size={15} /><span className="text-xs font-semibold">Decision guardrails on</span></div>
            <p className="text-[11px] leading-5 text-[#8492a4]">Every recommendation includes a confidence score, rationale, and an operator approval step.</p>
          </div>
        </aside>

        <main className="min-w-0 flex-1">
          <header className="sticky top-0 z-10 flex h-[72px] items-center justify-between border-b border-white/[0.07] bg-[#0c1118]/90 px-5 backdrop-blur-xl sm:px-8">
            <div className="flex items-center gap-3"><button className="rounded-lg p-2 text-[#8c9caf] hover:bg-white/[0.05] lg:hidden"><Menu size={20} /></button><div><div className="text-[11px] font-medium uppercase tracking-[0.16em] text-[#647489]">Tuesday · 15 September 2026</div><h1 className="font-display mt-0.5 text-lg font-semibold tracking-tight">{activeNav}</h1></div></div>
            <div className="flex items-center gap-3"><div className="hidden items-center gap-2 rounded-lg border border-white/[0.08] bg-[#111923] px-3 py-2 text-xs text-[#8d9bab] md:flex"><LocateFixed size={14} className="text-[#72b8b0]" /> Global network <ChevronRight size={13} /></div><button onClick={() => setAssistantOpen(true)} className="flex items-center gap-2 rounded-xl bg-[#f07c59] px-3.5 py-2.5 text-xs font-semibold text-[#161b21] shadow-[0_8px_22px_rgba(240,124,89,0.18)] transition hover:-translate-y-0.5"><Bot size={15} /> Ask Bob</button><div className="flex h-9 w-9 items-center justify-center rounded-full border border-[#39495b] bg-[#1b2a39] text-xs font-bold text-[#b8c5d2]">AS</div></div>
          </header>

          <div className="mx-auto max-w-[1500px] px-5 py-7 sm:px-8">
            {activeView === "overview" && <>
              <section className="mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><div className="mb-2 flex items-center gap-2 text-xs font-medium text-[#74c8b3]"><span className="h-2 w-2 animate-pulse rounded-full bg-[#74c8b3]" /> LIVE NETWORK SIGNAL</div><h2 className="font-display max-w-2xl text-3xl font-semibold leading-tight tracking-[-0.03em] text-[#edf3f8] sm:text-4xl">Make the next move<br /><span className="text-[#f07c59]">before the network does.</span></h2><p className="mt-3 max-w-xl text-sm leading-6 text-[#8190a2]">RouteGuard turns disruption signals into ranked actions across shipments, assets, and temperature-sensitive cargo.</p></div><button className="flex items-center gap-2 self-start rounded-xl border border-white/[0.1] bg-[#111923] px-3.5 py-2.5 text-xs font-medium text-[#aebccc] transition hover:border-[#4a6177] hover:text-white md:self-auto"><RefreshCw size={14} /> Refresh signals <span className="text-[#5d6d7e]">· 42s ago</span></button></section>

              <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                {[
                  { label: "At-risk shipments", value: "07", note: "2 critical · 3 high", icon: AlertTriangle, tone: "coral", trend: "+2" },
                  { label: "Cargo value exposed", value: "$1.84M", note: "Across 4 disruption zones", icon: PackageCheck, tone: "amber", trend: "+18%" },
                  { label: "Fleet utilisation", value: "76.4%", note: "12 assets available now", icon: Gauge, tone: "teal", trend: "+6.2%" },
                  { label: "Cold-chain health", value: "98.7%", note: "2 sensor events to review", icon: Snowflake, tone: "blue", trend: "-0.8%" },
                ].map((card) => { const Icon = card.icon; const tone = card.tone === "coral" ? "#f07c59" : card.tone === "amber" ? "#edba68" : card.tone === "teal" ? "#6fc8b5" : "#7aa9ee"; return <div key={card.label} className="group rounded-2xl border border-white/[0.08] bg-[#111923] p-5 transition hover:-translate-y-0.5 hover:border-white/[0.14]"><div className="mb-5 flex items-start justify-between"><div className="flex h-9 w-9 items-center justify-center rounded-xl" style={{ backgroundColor: `${tone}1a`, color: tone }}><Icon size={18} /></div><span className="flex items-center gap-1 text-[10px] font-semibold" style={{ color: tone }}>{card.trend.startsWith("-") ? <ArrowDownRight size={12} /> : <ArrowUpRight size={12} />}{card.trend}</span></div><div className="font-display text-3xl font-semibold tracking-tight text-[#f0f4f8]">{card.value}</div><div className="mt-1 text-xs font-medium text-[#a2afbd]">{card.label}</div><div className="mt-3 text-[11px] text-[#647486]">{card.note}</div></div> })}
              </section>

              <section className="mt-6 grid gap-5 xl:grid-cols-[1.42fr_0.98fr]">
                <div className="rounded-2xl border border-white/[0.08] bg-[#111923] p-5"><div className="mb-5 flex items-center justify-between"><div><div className="flex items-center gap-2"><h3 className="font-display text-base font-semibold">Priority queue</h3><span className="rounded-md bg-[#3a1d27] px-2 py-1 text-[10px] font-semibold text-[#ff8f7e]">7 needs action</span></div><p className="mt-1 text-xs text-[#6d7d8f]">Ranked by cargo exposure × time-to-impact</p></div><button onClick={() => setActiveNav("Disruptions")} className="text-xs font-semibold text-[#f07c59] hover:text-[#ff9a7e]">View all <ChevronRight className="inline" size={14} /></button></div><div className="overflow-x-auto"><table className="w-full min-w-[640px] text-left"><thead><tr className="border-b border-white/[0.07] text-[10px] font-semibold uppercase tracking-[0.14em] text-[#58697b]"><th className="pb-3 pl-1">Shipment</th><th className="pb-3">Lane</th><th className="pb-3">Exposure</th><th className="pb-3">Risk</th><th className="pb-3">Window</th><th className="pb-3 text-right">Action</th></tr></thead><tbody>{shipments.map((shipment) => <tr key={shipment.id} onClick={() => setSelectedShipment(shipment)} className={`cursor-pointer border-b border-white/[0.05] transition hover:bg-white/[0.025] ${selectedShipment.id === shipment.id ? "bg-[#162331]" : ""}`}><td className="py-4 pl-1"><div className="text-xs font-semibold text-[#dce5ed]">{shipment.id}</div><div className="mt-1 text-[11px] text-[#718094]">{shipment.cargo}</div></td><td className="py-4 text-xs text-[#a9b6c3]">{shipment.lane}</td><td className="py-4 text-xs font-semibold text-[#e3ebf2]">{shipment.value}</td><td className="py-4"><span className={`rounded-md border px-2 py-1 text-[10px] font-semibold ${riskTone[shipment.risk]}`}>{shipment.risk}</span></td><td className="py-4 text-xs text-[#a9b6c3]"><span className="flex items-center gap-1.5"><Clock3 size={12} className="text-[#6d7e91]" />{shipment.eta}</span></td><td className="py-4 text-right text-[11px] font-medium text-[#f07c59]">{shipment.action}</td></tr>)}</tbody></table></div></div>

                <div className="rounded-2xl border border-white/[0.08] bg-[#111923] p-5"><div className="mb-5 flex items-start justify-between"><div><div className="flex items-center gap-2"><h3 className="font-display text-base font-semibold">Network pulse</h3><span className="flex items-center gap-1.5 text-[10px] text-[#73c9af]"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#73c9af]" />Live</span></div><p className="mt-1 text-xs text-[#6d7d8f]">Disruption intensity · last 12 hours</p></div><MoreHorizontal size={18} className="text-[#6b7b8d]" /></div><div className="relative h-[165px] rounded-xl bg-[#0d151e] p-4"><div className="absolute inset-x-4 top-8 border-t border-dashed border-white/[0.08]" /><div className="absolute inset-x-4 top-[50%] border-t border-dashed border-white/[0.08]" /><div className="absolute inset-x-4 bottom-8 border-t border-dashed border-white/[0.08]" /><div className="relative flex h-full items-end justify-between gap-1">{[28,36,22,44,48,33,57,64,52,72,86,78,61,74,88,68,80,93,76,87].map((height, i) => <div key={i} className="group relative flex h-full flex-1 items-end"><div className={`w-full rounded-t-[3px] transition group-hover:brightness-125 ${height > 80 ? "bg-[#f07c59]" : height > 60 ? "bg-[#9a625c]" : "bg-[#36536b]"}`} style={{ height: `${height}%` }} /></div>)}</div></div><div className="mt-4 flex items-center justify-between text-[10px] text-[#5f7184]"><span>06:00</span><span>09:00</span><span>12:00</span><span>15:00</span><span>Now</span></div><div className="mt-5 grid grid-cols-2 gap-3 border-t border-white/[0.07] pt-4"><div><div className="text-[10px] uppercase tracking-wider text-[#5e7083]">Top signal</div><div className="mt-1 flex items-center gap-1.5 text-xs font-semibold text-[#f3c26e]"><Waves size={13} /> Rotterdam port strike</div></div><div><div className="text-[10px] uppercase tracking-wider text-[#5e7083]">Time to impact</div><div className="mt-1 flex items-center gap-1.5 text-xs font-semibold text-[#ff8e7a]"><Zap size={13} /> 18 minutes</div></div></div></div>
              </section>

              <section className="mt-5 grid gap-5 lg:grid-cols-[1fr_0.85fr]"><div className="rounded-2xl border border-white/[0.08] bg-[#111923] p-5"><div className="mb-5 flex items-center justify-between"><div><h3 className="font-display text-base font-semibold">Fleet ready to redeploy</h3><p className="mt-1 text-xs text-[#6d7d8f]">Under-utilised assets matched to current risk</p></div><button onClick={() => setActiveNav("Fleet utilisation")} className="text-xs font-semibold text-[#73c9af]">Open fleet view <ChevronRight className="inline" size={14} /></button></div><div className="space-y-3">{fleet.map((asset) => <div key={asset.asset} className="flex flex-wrap items-center gap-3 rounded-xl border border-white/[0.06] bg-[#0d151e] p-3 sm:flex-nowrap"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#1d2d3d] text-[#8bc3e6]"><Truck size={17} /></div><div className="min-w-[115px] flex-1"><div className="text-xs font-semibold text-[#dce5ed]">{asset.asset} <span className="ml-1 font-normal text-[#66778a]">· {asset.type}</span></div><div className="mt-1 text-[11px] text-[#708094]">{asset.location}</div></div><div className="w-[120px]"><div className="mb-1 flex justify-between text-[10px] text-[#7d8b9a]"><span>Utilisation</span><span className={asset.utilisation < 30 ? "text-[#ff957e]" : "text-[#aab7c4"}>{asset.utilisation}%</span></div><div className="h-1.5 overflow-hidden rounded-full bg-[#263442]"><div className={`h-full rounded-full ${asset.utilisation < 30 ? "bg-[#f07c59]" : "bg-[#5d9f9a]"}`} style={{ width: `${asset.utilisation}%` }} /></div></div><div className="w-full text-right text-[11px] font-medium text-[#8dc9b6] sm:w-[150px]">{asset.recommendation}</div></div>)}</div></div><div className="rounded-2xl border border-[#4b3027] bg-gradient-to-br from-[#201b1d] to-[#131921] p-5"><div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#4b2b27] text-[#ff927d]"><Snowflake size={16} /></div><h3 className="font-display text-base font-semibold">Cold-chain watch</h3></div><button onClick={() => setActiveNav("Cold chain")} className="text-[#8a9aad]"><MoreHorizontal size={18} /></button></div><div className="mb-4 flex items-end gap-3"><div className="font-display text-3xl font-semibold text-[#f5f7f9]">2</div><div className="pb-1 text-xs text-[#aab1b9]">active sensor events</div></div>{sensorEvents.slice(0, 2).map((event) => <div key={event.time} className="mb-2 flex items-center gap-3 rounded-lg bg-black/20 p-2.5"><div className={`h-2 w-2 rounded-full ${event.color === "red" ? "bg-[#ff816f]" : "bg-[#f2c262]"}`} /><div className="min-w-0 flex-1"><div className="flex justify-between text-[11px] font-semibold text-[#d9e0e7]"><span>{event.shipment}</span><span>{event.reading}</span></div><div className="mt-1 truncate text-[10px] text-[#8b97a5]">{event.duration} · {event.severity}</div></div></div>)}<button onClick={() => setAssistantOpen(true)} className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-white/[0.1] py-2.5 text-xs font-semibold text-[#c6d1dc] transition hover:bg-white/[0.05]"><BrainCircuit size={14} className="text-[#e3ad62]" /> Classify with Bob</button></div></section>
            </>}

            {activeView !== "overview" && <section className="animate-in fade-in duration-300"><div className="mb-6 rounded-2xl border border-white/[0.08] bg-[#111923] p-6"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><div className="mb-2 flex items-center gap-2 text-xs font-medium text-[#74c8b3]"><Radio size={14} /> OPERATIONS MODULE</div><h2 className="font-display text-3xl font-semibold tracking-tight">{activeNav}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-[#8190a2]">{activeView === "disruptions" ? "A ranked view of every disruption signal and the action it unlocks." : activeView === "cold" ? "Sensor-level visibility for shipments where one excursion can spoil the entire cargo value." : "Find idle capacity and match it to the lanes that need it most."}</p></div><button onClick={() => setAssistantOpen(true)} className="flex items-center gap-2 rounded-xl bg-[#f07c59] px-3.5 py-2.5 text-xs font-semibold text-[#161b21]"><Bot size={15} /> Ask Bob to prioritise</button></div></div>{activeView === "disruptions" && <div className="grid gap-4">{shipments.map((shipment) => <div key={shipment.id} className="flex flex-col gap-4 rounded-2xl border border-white/[0.08] bg-[#111923] p-5 md:flex-row md:items-center"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#3a1d27] text-[#ff8c78]"><AlertTriangle size={19} /></div><div className="flex-1"><div className="flex flex-wrap items-center gap-2"><span className="font-display font-semibold">{shipment.id}</span><span className={`rounded-md border px-2 py-1 text-[10px] font-semibold ${riskTone[shipment.risk]}`}>{shipment.risk}</span></div><div className="mt-1 text-xs text-[#8a99a9]">{shipment.lane} · {shipment.cargo} · {shipment.value} exposed</div></div><div className="text-left md:text-right"><div className="text-[10px] uppercase tracking-wider text-[#627387]">Recommended next move</div><div className="mt-1 text-xs font-semibold text-[#f3bd6c]">{shipment.action}</div></div><button className="rounded-lg border border-white/[0.09] p-2 text-[#8493a3] hover:bg-white/[0.05]"><ChevronRight size={17} /></button></div>)}</div>}{activeView === "cold" && <div className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]"><div className="rounded-2xl border border-white/[0.08] bg-[#111923] p-5"><div className="mb-5 flex items-center justify-between"><div><h3 className="font-display text-lg font-semibold">Temperature excursion log</h3><p className="mt-1 text-xs text-[#6d7d8f]">Streaming from 612 IoT sensor points</p></div><div className="flex items-center gap-2 text-xs text-[#73c9af]"><span className="h-2 w-2 animate-pulse rounded-full bg-[#73c9af]" /> Receiving</div></div><div className="overflow-x-auto"><table className="w-full min-w-[560px] text-left"><thead><tr className="border-b border-white/[0.07] text-[10px] uppercase tracking-[0.14em] text-[#58697b]"><th className="pb-3">Time</th><th className="pb-3">Shipment</th><th className="pb-3">Reading</th><th className="pb-3">Duration</th><th className="pb-3">Classification</th></tr></thead><tbody>{sensorEvents.map((event) => <tr key={event.time} className="border-b border-white/[0.05]"><td className="py-4 text-xs text-[#b4c0cc]">{event.time}</td><td className="py-4 text-xs font-semibold text-[#dce5ed]">{event.shipment}</td><td className="py-4 text-xs font-semibold text-[#f0c26d]">{event.reading}</td><td className="py-4 text-xs text-[#a1afbd]">{event.duration}</td><td className="py-4"><span className={`rounded-md px-2 py-1 text-[10px] font-semibold ${chipTone[event.color]}`}>{event.severity}</span></td></tr>)}</tbody></table></div></div><div className="rounded-2xl border border-[#4b3027] bg-[#201b1d] p-5"><div className="flex items-center gap-2 text-[#ff917b]"><Cpu size={16} /><span className="text-xs font-semibold uppercase tracking-wider">Bob classification</span></div><h3 className="mt-4 font-display text-2xl font-semibold">SHP-1048 needs<br />regulatory review.</h3><p className="mt-3 text-sm leading-6 text-[#a9adb3]">The 9.8°C excursion lasted 14 minutes. Bob linked it to the Rotterdam handoff delay and recommends a controlled transfer before the next checkpoint.</p><div className="mt-5 grid grid-cols-2 gap-2"><div className="rounded-xl bg-black/20 p-3"><div className="text-[10px] uppercase tracking-wider text-[#7f8791]">Confidence</div><div className="mt-1 text-lg font-semibold text-[#f3c571]">94%</div></div><div className="rounded-xl bg-black/20 p-3"><div className="text-[10px] uppercase tracking-wider text-[#7f8791]">Action window</div><div className="mt-1 text-lg font-semibold text-[#ff9783]">18 min</div></div></div><button onClick={() => setAssistantOpen(true)} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-[#f07c59] py-3 text-xs font-semibold text-[#171b21]"><Sparkles size={14} /> Generate handoff brief</button></div></div>}{activeView === "fleet" && <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{fleet.concat([{ asset: "TRK-113", type: "Box truck", location: "Lyon depot", utilisation: 26, status: "Idle", recommendation: "Pair with SHP-1039" }, { asset: "CNT-211", type: "Dry container", location: "Hamburg port", utilisation: 38, status: "Idle", recommendation: "Hold for surge" }]).map((asset) => <div key={asset.asset} className="rounded-2xl border border-white/[0.08] bg-[#111923] p-5"><div className="flex items-start justify-between"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#1c2b3a] text-[#8bc3e6]"><Container size={19} /></div><span className={`rounded-md px-2 py-1 text-[10px] font-semibold ${asset.status === "Idle" ? "bg-[#3a1d27] text-[#ff927d]" : "bg-[#173428] text-[#79d2a1]"}`}>{asset.status}</span></div><div className="mt-4 font-display text-lg font-semibold">{asset.asset}</div><div className="mt-1 text-xs text-[#8190a2]">{asset.type} · {asset.location}</div><div className="mt-5 flex items-center justify-between text-xs"><span className="text-[#708094]">Utilisation</span><span className="font-semibold text-[#dce6ee]">{asset.utilisation}%</span></div><div className="mt-2 h-2 overflow-hidden rounded-full bg-[#283746]"><div className={`h-full rounded-full ${asset.utilisation < 30 ? "bg-[#f07c59]" : "bg-[#5d9f9a]"}`} style={{ width: `${asset.utilisation}%` }} /></div><div className="mt-5 flex items-center gap-2 border-t border-white/[0.07] pt-4 text-xs font-medium text-[#8bcbb5]"><Zap size={13} /> {asset.recommendation}</div></div>)}</div>}</section>}
          </div>
        </main>
      </div>

      {assistantOpen && <div className="fixed inset-0 z-30 bg-black/50" onClick={() => setAssistantOpen(false)}><section className="absolute right-0 top-0 flex h-full w-full max-w-[440px] flex-col border-l border-white/[0.08] bg-[#101821] shadow-2xl" onClick={(event) => event.stopPropagation()}><div className="flex items-center justify-between border-b border-white/[0.08] px-5 py-5"><div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f07c59] text-[#141a20]"><Bot size={21} /></div><div><div className="font-display font-semibold">Ask Bob</div><div className="mt-0.5 flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-[#72cbb0]"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#72cbb0]" /> Decision assistant online</div></div></div><button onClick={() => setAssistantOpen(false)} className="rounded-lg p-2 text-[#8190a2] hover:bg-white/[0.05]"><X size={18} /></button></div><div className="flex-1 space-y-4 overflow-y-auto p-5">{messages.map((message, index) => <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}><div className={`max-w-[88%] rounded-2xl px-4 py-3 text-sm leading-6 ${message.role === "user" ? "rounded-br-md bg-[#2b5870] text-[#eef5fa]" : "rounded-bl-md border border-white/[0.08] bg-[#17232f] text-[#b9c6d1]"}`}>{message.role === "assistant" && <div className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#f08b68]"><BrainCircuit size={12} /> Bob analysis</div>}{message.text}</div></div>)}{askAssistant.isPending && <div className="flex items-center gap-2 text-xs text-[#8090a1]"><span className="flex gap-1"><span className="h-1.5 w-1.5 animate-bounce rounded-full bg-[#f07c59]" /><span className="h-1.5 w-1.5 animate-bounce rounded-full bg-[#f07c59] [animation-delay:80ms]" /><span className="h-1.5 w-1.5 animate-bounce rounded-full bg-[#f07c59] [animation-delay:160ms]" /></span> Bob is correlating live signals…</div>}</div><div className="border-t border-white/[0.08] p-4"><div className="mb-3 flex flex-wrap gap-2">{["What needs action first?", "Classify SHP-1048", "Find idle reefer assets"].map((prompt) => <button key={prompt} onClick={() => setQuery(prompt)} className="rounded-full border border-white/[0.1] px-3 py-1.5 text-[10px] text-[#97a7b8] transition hover:border-[#f07c59] hover:text-[#f6c0a8]">{prompt}</button>)}</div><div className="flex items-end gap-2 rounded-xl border border-white/[0.1] bg-[#0c131b] p-2 focus-within:border-[#688da0]"><textarea value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void handleAsk(); } }} placeholder="Ask about risk, routing, or fleet…" rows={2} className="min-h-[44px] flex-1 resize-none bg-transparent px-2 py-1 text-sm text-[#e4edf4] outline-none placeholder:text-[#5e6d7d]" /><button onClick={() => void handleAsk()} className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#f07c59] text-[#171b21] transition hover:brightness-110 disabled:opacity-50" disabled={!query.trim() || askAssistant.isPending}><Send size={15} /></button></div><div className="mt-2 flex items-center justify-center gap-1.5 text-[10px] text-[#5e6d7d]"><ShieldCheck size={11} /> Operator approval required before execution</div></div></section></div>}
    </div>
  );
}

// Explicitly reference a few imported icons in the compiled bundle for a stable visual vocabulary.
void ArrowDownRight;
void Activity;
void CheckCircle2;
void CircleHelp;
void Droplets;
void Filter;
void MessageSquareText;
void Gauge;
void PackageCheck;
void Truck;
