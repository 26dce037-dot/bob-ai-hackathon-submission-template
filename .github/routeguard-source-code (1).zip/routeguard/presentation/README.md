# Presentation

The submission deck covers the disruption problem, RouteGuard workflow, technical architecture, IBM Bob / watsonx integration boundary, and the impact path beyond the hackathon. The exported PDF is generated through the Slides tool and should be copied here as `slides.pdf` for the final repository.
