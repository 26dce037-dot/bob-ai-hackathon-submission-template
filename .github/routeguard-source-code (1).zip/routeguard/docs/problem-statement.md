# Problem statement

Supply-chain disruption is not a single-event problem. A port strike, severe weather system, or geopolitical restriction can change the viability of dozens of lanes at once, while the operational response is split across carrier portals, transportation-management systems, IoT feeds, and spreadsheet-based exception queues. By the time a coordinator has manually correlated those signals, the most valuable intervention window may already be gone.

The affected audience is the control-tower operator, logistics planner, and cold-chain quality manager responsible for keeping shipments moving under uncertainty. They need to answer four questions quickly: which shipments are affected, what alternative route or carrier is viable, which fleet assets can be redeployed, and whether a sensor event is operationally recoverable or requires regulatory review.

Cold-chain cargo makes the failure mode more severe. Vaccines, biologics, and perishables can carry six-figure or higher exposure, yet temperature excursions are often investigated after delivery rather than while the cargo is still recoverable. Meanwhile, an idle reefer truck or container may be available nearby while another lane is overloaded, creating a utilisation problem at the exact moment the network needs optionality.

Existing tools usually solve only one slice of the problem. A tracking dashboard shows where an asset is, a carrier portal shows a booking status, and an IoT platform shows a sensor reading. None of those views, by themselves, explain the combined operational priority or produce a defensible next move. RouteGuard addresses the gap by treating the shipment, disruption, asset, and sensor event as one decision graph.

The problem matters now because disruption frequency and supply-chain complexity have increased at the same time. The hackathon challenge explicitly calls for identifying affected shipments, recommending re-routing or carrier alternatives, finding idle fleet assets for redeployment, and classifying cold-chain excursions before delivery. RouteGuard is designed around that complete workflow rather than a single alert type.
