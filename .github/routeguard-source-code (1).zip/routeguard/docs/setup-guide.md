# Setup guide

This guide assumes a clean Ubuntu, macOS, or Windows terminal with Node.js 22 or newer and pnpm 10 available. The WebDev runtime supplies the server environment used by the hosted preview.

## Prerequisites

Install Node.js 22+, pnpm 10+, and Git. No external database or IBM credential is required for the seeded demo. A production integration additionally needs a watsonx.ai project, model credentials, and connector credentials for carrier, telemetry, and cold-chain systems.

## Install and run

```bash
git clone <your-public-repository-url>
cd routeguard
pnpm install
pnpm check
pnpm test
pnpm dev
```

Open the URL printed by the development server. The hosted WebDev preview for this build is recorded in `demo/live-demo-url.txt`.

## Environment variables

The managed WebDev scaffold supplies the runtime variables below. Do not commit a real `.env` file. The repository keeps a source-map entry in `src/README.md`; deployment platforms should inject secrets through their secret manager.

| Variable | Required for demo | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | No | MySQL/TiDB connection for future persisted event history. |
| `JWT_SECRET` | Hosted auth | Session signing secret supplied by WebDev. |
| `VITE_APP_ID` | Hosted auth | Manus OAuth application id. |
| `OAUTH_SERVER_URL` | Hosted auth | OAuth server base URL. |
| `VITE_OAUTH_PORTAL_URL` | Hosted auth | Frontend login portal URL. |
| `BUILT_IN_FORGE_API_URL` | Ask Bob | Server-side LLM gateway URL. |
| `BUILT_IN_FORGE_API_KEY` | Ask Bob | Server-side LLM gateway credential. |
| `WATSONX_PROJECT_ID` | Production only | IBM watsonx.ai project mapping. |
| `WATSONX_API_KEY` | Production only | IBM watsonx.ai credential. |

## Verify the application

After startup, confirm that the control tower renders four summary cards, the priority queue lists `SHP-1048`, and the left navigation opens Disruptions, Cold chain, and Fleet utilisation. Open **Ask Bob**, submit `What needs action first?`, and confirm that a response appears. The response may be supplied by the configured model or by the safe deterministic demo fallback.

## Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| `pnpm: command not found` | pnpm is not installed | Enable Corepack or install pnpm 10 globally. |
| The page is blank | Dev server is still compiling | Wait for the server to report healthy, then refresh. |
| Ask Bob returns the demo response | Model gateway is unavailable or not configured | This is expected in offline demo mode; inject the server-side LLM variables for live reasoning. |
| TypeScript errors after editing | A client/server contract changed | Run `pnpm check` and inspect the first reported file. |
| Tests fail on a clean machine | Dependencies are missing | Run `pnpm install` before `pnpm test`. |

## Clean-room verification record

The reproducible validation commands are `pnpm check` and `pnpm test`. The current project has been checked in the managed WebDev environment, which reports no TypeScript errors and a healthy preview server.
