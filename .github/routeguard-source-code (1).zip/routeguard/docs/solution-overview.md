# Solution overview

RouteGuard is a disruption-aware operations cockpit. It ingests a normalized set of shipment, disruption, fleet, and sensor events and turns them into a ranked priority queue. Each queue item carries the information needed to act: cargo value at risk, time-to-impact, current lane, recommended alternative, and an explicit operator action.

The core mechanism is a decision-oriented correlation layer. Instead of asking an operator to scan four systems, RouteGuard joins the signals into one operational context. A port strike can therefore elevate a shipment, trigger a viable alternative-lane suggestion, and search for an idle reefer asset near the handoff. A temperature excursion can be interpreted alongside the shipment's handoff delay and classified as a watch, recovery, or regulatory-review event.

Bob is load-bearing in the workflow. The Ask Bob panel receives the bounded operational context from the server and returns a concise answer that states the priority, explains the evidence, and recommends an operator-approved next step. The production integration boundary is the server-side `assistant.ask` procedure, where a watsonx.ai / Granite call can be used without exposing credentials to the browser. The demo includes a deterministic fallback so judges can reproduce the experience even when external credentials are unavailable.

This is intentionally different from a naive chatbot. RouteGuard does not ask Bob to invent a route from a blank prompt; it gives Bob a structured, current decision context and requires the response to stay inside an approval guardrail. The user experience is a cockpit first and a conversation second: operators can scan the ranked queue, drill into cold-chain evidence, inspect idle capacity, or ask Bob to explain the next best move.

The current demo uses seeded data to make the walkthrough stable. In a full deployment, the same contract can be connected to carrier APIs, Instana or equivalent telemetry, a cold-chain IoT stream, and a governed watsonx.ai project.
