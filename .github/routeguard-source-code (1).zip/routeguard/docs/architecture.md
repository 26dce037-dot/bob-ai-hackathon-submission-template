# Architecture

```mermaid
graph TD
    U[Operations user] --> UI[RouteGuard React control tower]
    UI -->|typed tRPC call| API[Express + tRPC server]
    API --> CORR[Decision context builder]
    CORR --> SHIP[Shipment + disruption events]
    CORR --> FLEET[Fleet availability events]
    CORR --> IOT[Cold-chain IoT sensor events]
    API --> BOB[Ask Bob procedure]
    BOB --> LLM[watsonx.ai / Granite integration boundary]
    LLM --> BOB
    BOB --> UI
    UI --> APPROVAL[Operator approval guardrail]
    APPROVAL --> EXEC[Future carrier / TMS execution adapter]
```

| Component | Technology | Responsibility |
| --- | --- | --- |
| Control tower | React 19 + TypeScript + Tailwind | Shows ranked risk, fleet capacity, sensor status, and actions. |
| Typed API | Express + tRPC | Keeps the browser/server contract explicit and validates assistant input. |
| Assistant | `server/routers.ts` + WebDev LLM helper | Correlates the bounded context and produces a concise, explainable recommendation. |
| Model boundary | IBM watsonx.ai / Granite-ready prompt contract | Provides governed language reasoning without moving credentials to the client. |
| Event adapters | Future carrier, Instana, and IoT connectors | Normalize external signals into the RouteGuard decision context. |
| Approval layer | UI guardrail and future execution adapter | Separates a recommendation from an irreversible logistics action. |

## End-to-end data flow

A shipment or sensor event enters through a future connector adapter and is normalized into a common operational context. The decision context builder correlates the event with cargo value, lane, estimated time-to-impact, nearby fleet assets, and the disruption cause. The React UI renders the result as a ranked queue and module-specific views.

When an operator asks Bob a question, the browser sends only the question and bounded demo context to the server-side `assistant.ask` procedure. The procedure calls the configured model helper, constrains the response to priority, rationale, and next step, and returns the answer to the panel. If the model is unavailable, the deterministic fallback preserves the demo journey. No action is executed automatically.

## Security and scalability notes

Credentials are server-side only. The browser never receives model keys or carrier tokens. Input length is bounded, and the assistant is instructed never to claim that an action was executed. In production, user roles should be mapped to operator, supervisor, and admin permissions, while execution adapters should require a second approval for carrier changes or cargo holds.

The UI is stateless and the current demo uses seeded data, which makes it easy to deploy behind a managed runtime. A production version can move the decision context to a stream processor and persist event history in a relational database or event store. The correlation contract keeps the visual layer independent of the specific carrier or IoT vendor.
