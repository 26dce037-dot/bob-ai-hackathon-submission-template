# Contributing to RouteGuard

For the hackathon submission, keep all application changes inside the repository and never commit credentials. Use feature branches for team review, run `pnpm check` and `pnpm test` before pushing, and update the relevant documentation when behavior changes. Do not modify the validation workflow supplied by the Bobathon template when this project is copied into the final submission repository.
